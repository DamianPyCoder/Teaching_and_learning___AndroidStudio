package com.example.pantallatactil;

import androidx.appcompat.app.AppCompatActivity;

import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnTouchListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView entrada = (TextView) findViewById(R.id.textViewEntrada);
        entrada.setOnTouchListener(this);


        /* COMPROBACIÓN MULTITOUCH

        if(getPackageManager().hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN_MULTITOUCH)){
            Toast.makeText(MainActivity.this, "El dispositivo tiene capacidad táctil multitouch",Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(MainActivity.this, "El dispositivo NO tiene capacidad táctil multitouch",Toast.LENGTH_LONG).show();
        }*/

    }

    @Override
    public boolean onTouch(View view, MotionEvent motionEvent){
        TextView salida = (TextView) findViewById(R.id.TextViewSalida);
        //salida.append(motionEvent.toString()+"\n");

        String acciones[] = {"ACTION_DOWN", "ACTION_UP", "ACTION_MOVE", "ACTION_CANCEL", "ACTION_OUTSIDE", "ACTION_POINTER_DOWN", "ACTION_POINTER_UP"};
        int accion = motionEvent.getAction();
        int codigoAccion = accion & motionEvent.ACTION_MASK;
        int iPuntero = (accion & MotionEvent.ACTION_POINTER_INDEX_MASK) >> MotionEvent.ACTION_POINTER_INDEX_SHIFT;
        salida.append(acciones[codigoAccion]);
        for (int i = 0; i < motionEvent.getPointerCount(); i++){
            salida.append(" puntero:"+motionEvent.getPointerId(i) +
                    " indice: "+motionEvent.findPointerIndex(motionEvent.getPointerId(i)) +
                    " x:" + motionEvent.getX(i) +
                    " y:" + motionEvent.getY(i));
        }
        salida.append("\n");
        return true;
    }
}