package com.example.intenciones;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.Manifest;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    // ------------------------------------------------------------------------------------
    // --------------------------------   VARIAS   ----------------------------------------
    // ------------------------------------------------------------------------------------
    public void googleMaps (View view){
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:41,656313, -0,877351"));
        startActivity(intent);
    }

    public void abrirStreetView(View view) {
        Uri gmmIntentUri = Uri.parse("google.streetview:cbll=41.656313,-0.877351");
        Intent intent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
        intent.setPackage("com.google.android.apps.maps");
        startActivity(intent);
    }
    public void mandarCorreo (View v){
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_SUBJECT, "asunto");
        i.putExtra(Intent.EXTRA_TEXT, "texto correo");
        i.putExtra(Intent.EXTRA_EMAIL, new String[]{"jtomas@upv.es"});
        startActivity(i);
    }

    // ------------------------------------------------------------------------------------
    // --------------------------------   CÁMARA   ----------------------------------------
    // ------------------------------------------------------------------------------------
    public void tomarFoto (View view){
        //Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        //startActivity(intent);
        checkPermission_CAMERA();
    }
    void checkPermission_CAMERA(){
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)!= PackageManager.PERMISSION_GRANTED){
            if(ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.CAMERA)) {
            } else {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA},24);
                }
            } else {
                callCamara();
            }
        }

        public void callCamara(){
        Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
        startActivity(intent);
    }






    // ------------------------------------------------------------------------------------
    // -------------------------------   LLAMADAS   ---------------------------------------
    // ------------------------------------------------------------------------------------

    public void llamadaTelefono (View view){
        Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:0000000"));
        startActivity(intent);

    }
    void checkPermission_CALL(){
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE)!= PackageManager.PERMISSION_GRANTED){
            if(ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.CALL_PHONE)) {
            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CALL_PHONE},42);
            }
        } else {
            callPhone();
        }
    }
    public void callPhone(){
        Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:0000000"));
        startActivity(intent);
    }
    public void llamadaTelefonoCall(View view) {
        //Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:0000000"));
        //startActivity(intent);
        checkPermission_CALL();
    }


    // ------------------------------------------------------------------------------------
    // -----------------------------   BÚSQUEDA WEB   -------------------------------------
    // ------------------------------------------------------------------------------------

    public void pgWeb (View v){
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.google.es/"));
        startActivity(intent);
    }


    public void checkPermission_SEARCH(){
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.INTERNET)!= PackageManager.PERMISSION_GRANTED){
            if(ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.INTERNET)) {
            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.INTERNET},42);
            }
        } else {
            searchWeb();
        }
    }
    public void searchWeb(){
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.google.com/"));
        startActivity(intent);
    }



    public void abrirPaginaWebBusqueda(View view) {
        //Intent intent = new Intent(Intent.ACTION_WEB_SEARCH, Uri.parse("https://www.google.com"));
        //startActivity(intent);
        checkPermission_SEARCH();
    }


    // ------------------------------------------------------------------------------------
    // ----------------------------   CONTROL ERRORES   -----------------------------------
    // ------------------------------------------------------------------------------------


    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 24:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    callCamara();
                } else {

                }
                break;
            case 42:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    callPhone();
                    //Toast.makeText(this, "boton pulsado y garantizado", Toast.LENGTH_SHORT).show();
                } else {
                }
                break;

            case 33:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    callPhone();
                } else {
                }
                break;
        }
    }

}