package com.example.mediaplayer;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private MediaPlayer mp;
    private Button b1;
    private int posicion=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //MediaPlayer mp = MediaPlayer.create(this, R.raw.audio );
        //mp.start();
        b1=(Button) findViewById(R.id.BotonReset);
    }

    public void iniciar(View v){
        destruir();
        mp = MediaPlayer.create(this, R.raw.audio);
        mp.start();
        String op = b1.getText().toString();
        if(op.equals("NO REPRODUCIR EN FORMA CIRCULAR"))
            mp.setLooping(false);
        else
            mp.setLooping(true);
    }
    public void destruir(){
        if(mp != null)
            mp.release();
    }

    public void pausar(View v){
        if (mp!=null && mp.isPlaying()){
            posicion = mp.getCurrentPosition();
            mp.pause();
        }
    }

    public void continuar (View v){
        if (mp!= null && mp.isPlaying() == false){
            mp.seekTo(posicion);
            mp.start();
        }
    }

    public void detener(View v){
        if(mp!=null){
            mp.stop();
            posicion=0;
        }
    }

    public void circular(View v){
        detener(null);
        String op = b1.getText().toString();
        if(op.equals("NO REPRODUCIR EN FORMA CIRCULAR"))
            b1.setText("SI REPRODUCIR EN FORMA CIRCULAR");
        else
            b1.setText("NO REPRODUCIR EN FORMA CIRCULAR");
    }
}