package com.example.comunicacionactividades;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {

    private TextView tv;
    private Button btnAceptar, btnRechazar;
    private String retorno;

    protected void onCreate (Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        tv = (TextView) findViewById(R.id.textView3);

        btnAceptar = (Button) findViewById(R.id.button2);
        btnRechazar = (Button) findViewById(R.id.button3);

        Bundle extra = getIntent().getExtras();
        String nombre = extra.getString("nombre");

        tv.setText("Hola "+nombre+" ¿Aceptas las concidiones?");

        btnAceptar.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                retorno = "ACEPTAR";
                finalizar();
            }
        });
        btnRechazar.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                retorno = "RECHAZAR";
                finalizar();
            }
        });
    }
public void finalizar(){
        Intent i = new Intent();
        i.putExtra("resultado", retorno);
        setResult(RESULT_OK, i);
        finish();
}


}
