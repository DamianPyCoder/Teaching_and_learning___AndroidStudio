package com.example.comunicacionactividades;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import kotlin.Suppress;

public class MainActivity extends AppCompatActivity {

    private EditText et1;
    private TextView tvRes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et1 = (EditText) findViewById(R.id.editText);
        tvRes = (TextView) findViewById(R.id.textView2);
    }

    //@SuppressLint("MissingSuperCall")
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        System.out.println("CODE " + requestCode);
        if (requestCode == 1234 && resultCode == RESULT_OK) {
            String code = data.getExtras().getString("resultado");
            tvRes.setText("Resultado: " + code);
        }
    }

    public void Verificar(View v){
        Intent i = new Intent(this, SecondActivity.class);
        String nom = et1.getText().toString();
        i.putExtra("nombre", nom);
        startActivityForResult(i, 1234);

    }
}