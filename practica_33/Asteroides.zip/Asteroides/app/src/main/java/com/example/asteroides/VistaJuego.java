package com.example.asteroides;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.PathShape;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;

import androidx.core.content.ContextCompat;
import androidx.preference.PreferenceManager;

import java.util.Vector;
import java.util.jar.Attributes;

public class VistaJuego extends View {

    private Grafico nave;
    private int giroNave;
    private float aceleracionNave;
    private static final int PASO_GIRO_NAVE = 5;
    private static final float PASO_ACELERACION_NAVE = 0.5f;
    private Vector<Grafico> Asteroides;
    private int numAsteroides=5;
    private int numFragmentos=3;


    private ThreadJuego thread = new ThreadJuego();
    private static int PERIODO_PROCESO = 50;
    private long ultimoProceso = 0;

    private float mX=0, mY=0;
    private boolean disparo=false;

    @Override
    public boolean onTouchEvent (MotionEvent event){
        super.onTouchEvent(event);
        float x = event.getX();
        float y = event.getY();
        switch (event.getAction()){
            case MotionEvent.ACTION_MOVE:
                float dx = Math.abs(x - mX);
                float dy = Math.abs(y - mY);
                if (dy<6 && dx>6){
                    giroNave = Math.round((x - mX) / 2);
                    disparo = false;
                } else if (dx<6 && dy>6){
                    //aceleracionNave = Math.round((mY - y)/25);
                    aceleracionNave = Math.abs(Math.round((mY - y)/25));
                    disparo = false;
                }
                break;
            case MotionEvent.ACTION_UP:
                giroNave = 0;
                aceleracionNave = 0;
                if(disparo){
                    //ActivaMisil();
                }
                break;
        }
        mX=x; mY=y;
        return true;
    }

    public VistaJuego(Context context, AttributeSet attrs){
        super(context, attrs);
        Drawable drawableNave, drawableAsteroide, drawableMisil;

        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(getContext());
        if(pref.getString("graficos","1").equals("0")){
            //ASTEROIDE VECTORIAL
            Path pathAsteroide = new Path();
            pathAsteroide.moveTo((float) 0.3, (float) 0.0);
            pathAsteroide.lineTo((float) 0.6, (float) 0.0);
            pathAsteroide.lineTo((float) 0.6, (float) 0.3);
            pathAsteroide.lineTo((float) 0.8, (float) 0.2);
            pathAsteroide.lineTo((float) 1.0, (float) 0.4);
            pathAsteroide.lineTo((float) 0.8, (float) 0.6);
            pathAsteroide.lineTo((float) 0.9, (float) 0.9);
            pathAsteroide.lineTo((float) 0.8, (float) 1.0);
            pathAsteroide.lineTo((float) 0.4, (float) 1.0);
            pathAsteroide.lineTo((float) 0.0, (float) 0.6);
            pathAsteroide.lineTo((float) 0.0, (float) 0.2);
            pathAsteroide.lineTo((float) 0.3, (float) 0.0);
            ShapeDrawable dAsteroide = new ShapeDrawable(
                    new PathShape(pathAsteroide, 1, 1));
            dAsteroide.getPaint().setColor(Color.WHITE);
            dAsteroide.getPaint().setStyle(Paint.Style.STROKE);
            dAsteroide.setIntrinsicWidth(50);
            dAsteroide.setIntrinsicHeight(50);
            drawableAsteroide = dAsteroide;


            //NAVE VECTORIAL
            Path pathNave = new Path();
            pathNave.moveTo((float)0.0,(float)0.0);
            pathNave.lineTo((float)1.0,(float)0.5);
            pathNave.lineTo((float)0.0,(float)1.0);
            pathNave.lineTo((float)0.0,(float)0.0);


            ShapeDrawable dNave = new ShapeDrawable(
                    new PathShape(pathNave, 1, 1));
            dNave.getPaint().setColor(Color.WHITE);
            dNave.getPaint().setStyle(Paint.Style.STROKE);
            dNave.setIntrinsicWidth(20);
            dNave.setIntrinsicHeight(15);
            drawableNave = dNave;
            setBackgroundColor(Color.BLACK);
        }else {
            drawableAsteroide = ContextCompat.getDrawable(context, R.drawable.asteroide1);
            drawableNave = ContextCompat.getDrawable(context, R.drawable.nave);
        }

        //drawableNave = ContextCompat.getDrawable(context, R.drawable.nave);

        nave = new Grafico(this, drawableNave);

        Asteroides = new Vector<Grafico>();
        for (int i = 0; i <numAsteroides; i++){
            Grafico asteroide = new Grafico(this, drawableAsteroide);
            asteroide.setIncY(Math.random()*4-2);
            asteroide.setIncX(Math.random()*4-2);
            asteroide.setAngulo((int)(Math.random()*360));
            asteroide.setRotacion((int)(Math.random()*8-4));
            Asteroides.add(asteroide);
        }
    }
    @Override protected void onSizeChanged(int ancho, int alto, int ancho_anter, int alto_anter){
        super.onSizeChanged(ancho, alto, ancho_anter, alto_anter);

        ultimoProceso = System.currentTimeMillis();
        thread.start();

        nave.setPosX(ancho/2-nave.getAncho()/2);
        nave.setPosY(alto/2-nave.getAncho()/2);

        for(Grafico asteroide: Asteroides){
            do {
                asteroide.setPosX(Math.random() * (ancho - asteroide.getAncho()));
                asteroide.setPosY(Math.random() * (alto - asteroide.getAlto()));
            } while (asteroide.distancia(nave)<(ancho+alto)/5);
        }
    }

    @Override protected synchronized void onDraw(Canvas canvas){
        super.onDraw(canvas);

        nave.dibujaGrafico(canvas);

        for(Grafico asteroide: Asteroides){
            asteroide.dibujaGrafico(canvas);
        }
    }

    protected synchronized void actualizaFisica(){
        long ahora = System.currentTimeMillis();
        if (ultimoProceso + PERIODO_PROCESO > ahora){
            return;
        }
        double retardo = (ahora - ultimoProceso) / PERIODO_PROCESO;
        ultimoProceso = ahora;
        nave.setAngulo((int) (nave.getAngulo()+giroNave*retardo));
        double nIncX = nave.getIncX()+aceleracionNave *
                Math.cos(Math.toRadians(nave.getAngulo()))*retardo;
        double nIncY = nave.getIncY()+aceleracionNave *
                Math.sin(Math.toRadians(nave.getAngulo()))*retardo;
        if(Math.hypot(nIncX,nIncY) <= Grafico.MAX_VELOCIDAD){
            nave.setIncX(nIncX);
            nave.setIncY(nIncY);
        }
        nave.incrementaPos(retardo);
        for(Grafico asteroide : Asteroides){
            asteroide.incrementaPos(retardo);
        }
    }

    public class ThreadJuego extends Thread {
        @Override
        public void run(){
            while(true){
                actualizaFisica();
            }
        }
    }

    @Override
    public boolean onKeyDown(int codigoTecla, KeyEvent evento){
        super.onKeyDown(codigoTecla, evento);
        boolean procesada = true;
        switch (codigoTecla){
            case KeyEvent.KEYCODE_DPAD_UP:
                aceleracionNave = +PASO_ACELERACION_NAVE;
                break;
            case KeyEvent.KEYCODE_DPAD_LEFT:
                giroNave = +PASO_GIRO_NAVE;
                break;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
                //ActivaMisil();
                break;
            default:
                procesada = false;
                break;
        }
        return procesada;
    }

    public boolean onKeyUp (int codigoTecla, KeyEvent evento){
        super.onKeyUp(codigoTecla, evento);
        boolean procesada = true;
        switch (codigoTecla){
            case KeyEvent.KEYCODE_DPAD_UP:
                aceleracionNave = 0;
                break;
            case KeyEvent.KEYCODE_DPAD_LEFT:
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                giroNave = 0;
                break;
            default:
                procesada = false;
                break;
        }
        return procesada;
    }

}
