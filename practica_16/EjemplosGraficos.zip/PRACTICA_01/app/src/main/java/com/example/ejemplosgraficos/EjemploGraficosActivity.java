package com.example.ejemplosgraficos;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.os.Bundle;
import android.view.View;

import java.lang.reflect.Type;

public class EjemploGraficosActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(new EjemploView(this));
        setContentView(R.layout.activity_main);

    }

    /*
    public class EjemploView extends View {

        //private Drawable miImagen;
        private ShapeDrawable miImagen;
        public EjemploView (Context context){
            super(context);

            //miImagen = ContextCompat.getDrawable(context, R.mipmap.ic_launcher);
            //miImagen = ContextCompat.getDrawable(context, R.drawable.estrella);
            //miImagen = ContextCompat.getDrawable(context, R.drawable.baseline_arrow_drop_up_24);
            //miImagen = ContextCompat.getDrawable(context, R.drawable.ace);
            //miImagen.setBounds(30,30,1000,1000);


            miImagen = new ShapeDrawable(new OvalShape());
            miImagen.getPaint().setColor(0xff0000ff);
            miImagen.setBounds(10,10,310,60);

        }

        //EJERCICIO 2:
        protected void onDraw(Canvas canvas){

            miImagen.draw(canvas);
        }
        */

        //EJERCICIO 1:
        // PARTE 1
        /*protected void onDraw(Canvas canvas){
            Paint pincel = new Paint();
            pincel.setColor(Color.BLUE);
            pincel.setStrokeWidth(8);
            pincel.setStyle(Paint.Style.STROKE);
            canvas.drawCircle(150,150,100,pincel);

            //pincel.setColor(Color.argb(127, 255, 0, 0));
            //pincel.setColor(0x7FFF0000);
            pincel.setColor(EjemploGraficosActivity.this.getColor(R.color.color_circulo));
            canvas.drawCircle(150, 250, 100, pincel);
        }
        */
        //PARTE 2
        /*protected void onDraw(Canvas canvas){
            Path trazo = new Path();
            //trazo.addCircle(150, 150, 100, Path.Direction.CCW);
            trazo.addCircle(150, 150, 100, Path.Direction.CW);
            canvas.drawColor(Color.WHITE);
            Paint pincel = new Paint();
            pincel.setColor(Color.BLUE);
            pincel.setStrokeWidth(8);
            pincel.setStyle(Paint.Style.STROKE);
            canvas.drawPath(trazo, pincel);
            pincel.setStrokeWidth(1);
            pincel.setStyle(Paint.Style.FILL);
            pincel.setTextSize(20);
            pincel.setTypeface(Typeface.SANS_SERIF);
            //canvas.drawTextOnPath("Desarrollo de apps", trazo, 10, 40, pincel);
            canvas.drawTextOnPath("Desarrollo de apps móviles con android studio", trazo, 0, -40, pincel);
        }*/
        //PARTE 3
        /*protected void onDraw(Canvas canvas){
            Path trazo = new Path();
            trazo.moveTo(50,100);
            trazo.cubicTo(60,70,150,65,200,110);
            trazo.lineTo(300,200);

            canvas.drawColor(Color.WHITE);
            Paint pincel = new Paint();
            pincel.setColor(Color.BLUE);
            pincel.setStrokeWidth(8);
            pincel.setStyle(Paint.Style.STROKE);
            canvas.drawPath(trazo, pincel);
            pincel.setStrokeWidth(1);
            pincel.setStyle(Paint.Style.FILL);
            pincel.setTextSize(20);
            pincel.setTypeface(Typeface.SANS_SERIF);
            //canvas.drawTextOnPath("Desarrollo de apps", trazo, 10, 40, pincel);
            canvas.drawTextOnPath("Desarrollo de apps móviles con android studio", trazo, 0, -40, pincel);
        }


    }*/
}