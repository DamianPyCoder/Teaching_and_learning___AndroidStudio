package com.example.asteroides;
import android.app.Activity;
import android.os.Bundle;
public class AcercaDeActivity extends Activity {
    @Override
    public void onCreate(Bundle saveInstanceState){
        super.onCreate(saveInstanceState);
        setContentView(R.layout.acercade);
    }
}
