package com.example.intentservice;

import static android.app.Service.START_STICKY;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.SystemClock;

import java.security.Provider;

public class ServicioOperacion extends Service {

    @Override
    public int onStartCommand(Intent i, int flags, int idArranque){
        double n = i.getExtras().getDouble("numero");
        SystemClock.sleep(100000);
        MainActivity.salida.append(n*n+"\n");
        return START_STICKY;
    }
    @Override
    public IBinder onBind(Intent arg0){
        return null;
    }

}
