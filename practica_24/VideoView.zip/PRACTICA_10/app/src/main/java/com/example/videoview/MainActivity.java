package com.example.videoview;

import androidx.appcompat.app.AppCompatActivity;

import android.net.Uri;
import android.os.Bundle;
import android.widget.MediaController;
import android.widget.VideoView;

public class MainActivity extends AppCompatActivity {

    private VideoView mVideoView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mVideoView = (VideoView) findViewById(R.id.surface_view);

        String uriPath = "android.resource://"+getPackageName() + "/" + R.raw.depeche;
        Uri uri = Uri.parse(uriPath);
        mVideoView.setVideoURI(uri);
        //mVideoView.setVideoPath("file:///sdcard/depeche.mp4");

        mVideoView.setMediaController(new MediaController(this));
        mVideoView.start();
        mVideoView.requestFocus();
    }
}